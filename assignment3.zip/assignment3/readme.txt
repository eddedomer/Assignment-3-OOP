# Assignment-3-OOP
The third assignment in my OOP Class.

Edvin did tasks: 1.1 to 1.5
Daniel did tasks: 1.6 to 1.10

Since we had a lot of troubleshooting on task 1.11
we decided to do it togheter.

For the Epic Feature 2
Daniel created the classes and Edvin implemented them.
